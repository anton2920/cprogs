#ifndef HEADER
#define HEADER

/* Standard headers */
#include <stdlib.h>
#include <limits.h>
#include <stdio.h>

/* Source.cpp */
void EnterRow(int *A, int n);

#endif 